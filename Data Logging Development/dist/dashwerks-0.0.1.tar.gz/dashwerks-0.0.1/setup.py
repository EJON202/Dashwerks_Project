from distutils.core import setup
setup(name='dashwerks', 
        version='0.0.1', description='dashwerks racing system', author='Ethan Montague',
        author_email='ejmontague101@gmail.com',
        packages=['systemData'],
        package_dir={"":"src"},
)